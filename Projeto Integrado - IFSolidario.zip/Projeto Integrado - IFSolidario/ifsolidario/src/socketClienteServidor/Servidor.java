/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package socketClienteServidor;

import bean.Usuario;
import dao.UsuarioJpaController;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Persistence;

/**
 *
 * @author aleaguado
 */
public class Servidor {

    private int porta;
    private List<PrintStream> clientes;
    private ObjectInputStream input;
    ObjectInputStream inputCliente;
    private Usuario u;

    /*public Servidor(ObjectInputStream inputCliente) {
        this.inputCliente = inputCliente;
    }*/

    public void rodar() {
        try {

            //this.clientes = new ArrayList<PrintStream>();
            this.input = new ObjectInputStream(inputCliente);
            Object aux = input.readObject();

            if (aux instanceof Usuario) {
                u = (Usuario) aux;
                System.out.println(u.getNome());
            }

            ServerSocket servidor = new ServerSocket(porta);
            while (true) {
                Socket cliente = servidor.accept();
                System.out.println("Nova conexão com o cliente " + cliente.getInetAddress().getHostAddress());

                PrintStream ps = new PrintStream(cliente.getOutputStream());
                this.clientes.add(ps);

                TrataCliente tc = new TrataCliente(cliente.getInputStream(), this);
                new Thread(tc).start();
            }
        } catch (Exception e) {
            System.out.println("Erro " + e.getMessage());
        }
    }

    public void usuario(Usuario u) {
        try {
            UsuarioJpaController usuarioDAO = new UsuarioJpaController(Persistence.createEntityManagerFactory("IFSolidarioPU"));
            usuarioDAO.create(u);
        } catch (Exception e) {

        }
    }

    public void distribuiMensagem(String msg) {
        // envia msg para todo mundo
        for (PrintStream cliente : this.clientes) {
            cliente.println(msg);
        }
    }

    public void setPorta(int portaP) {
        porta = portaP;
    }
}

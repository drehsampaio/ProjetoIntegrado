/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package socketClienteServidor;

import bean.Usuario;
import dao.UsuarioJpaController;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;
import javax.persistence.Persistence;
import javax.swing.JOptionPane;

/**
 *
 * @author ifsp
 */
public class Cliente {
    private int porta;
        private String end;
    
    public void rodar(Usuario u) {
      try {
            //Scanner lerTeclado = new Scanner(System.in);
            Socket cliente = new Socket(end, porta);
            System.out.println("Conectado ao servidor!");
            
             // thread para receber mensagens do servidor ========
               ReceberMsg r = new ReceberMsg(u);
               new Thread(r).start();
            //=====================================================
  
            PrintStream saida = new PrintStream(cliente.getOutputStream());
            UsuarioJpaController usuarioDAO = new UsuarioJpaController(Persistence.createEntityManagerFactory("IFSolidarioPU"));
        
        try {            
            usuarioDAO.create(u);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
            //while (lerTeclado.hasNextLine()) {
              //  saida.println("\n" + marca + "\n" + modelo + "\n" + cor );
            //}
            saida.close();
            //lerTeclado.close();
            cliente.close();
        } catch (Exception e) {
            System.out.println("Erro!");
        } 
     }
    //Método para setar os dados
     public void setDados(int portaP, String ip, String n, String ma, String mo, String c){
        porta =  portaP;
        end = ip;
     }  
}

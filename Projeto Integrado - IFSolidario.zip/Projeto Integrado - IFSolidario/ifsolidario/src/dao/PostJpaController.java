/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import bean.Categoria;
import bean.Usuario;
import bean.Comentario;
import bean.Post;
import conexao.Conexao;
import dao.exceptions.IllegalOrphanException;
import dao.exceptions.NonexistentEntityException;
import dao.exceptions.PreexistingEntityException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author adria
 */
public class PostJpaController implements Serializable {
    private String mens;
    private Connection con;
    
    public String getMens() {
        return mens;
    }

    public void setMens(String mens) {
        this.mens = mens;
    }
    
    public PostJpaController(EntityManagerFactory emf) {
        this.emf = emf;
        this.con = Conexao.getConnection();
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Post post) throws PreexistingEntityException, Exception {
        if (post.getComentarioList() == null) {
            post.setComentarioList(new ArrayList<Comentario>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Categoria categoria = post.getCategoria();
            if (categoria != null) {
                categoria = em.getReference(categoria.getClass(), categoria.getIdcategoria());
                post.setCategoria(categoria);
            }
            Usuario prontuario = post.getProntuario();
            if (prontuario != null) {
                prontuario = em.getReference(prontuario.getClass(), prontuario.getProntuario());
                post.setProntuario(prontuario);
            }
            List<Comentario> attachedComentarioList = new ArrayList<Comentario>();
            for (Comentario comentarioListComentarioToAttach : post.getComentarioList()) {
                comentarioListComentarioToAttach = em.getReference(comentarioListComentarioToAttach.getClass(), comentarioListComentarioToAttach.getIdcomentario());
                attachedComentarioList.add(comentarioListComentarioToAttach);
            }
            post.setComentarioList(attachedComentarioList);
            em.persist(post);
            if (categoria != null) {
                categoria.getPostList().add(post);
                categoria = em.merge(categoria);
            }
            if (prontuario != null) {
                prontuario.getPostList().add(post);
                prontuario = em.merge(prontuario);
            }
            for (Comentario comentarioListComentario : post.getComentarioList()) {
                Post oldPostOfComentarioListComentario = comentarioListComentario.getPost();
                comentarioListComentario.setPost(post);
                comentarioListComentario = em.merge(comentarioListComentario);
                if (oldPostOfComentarioListComentario != null) {
                    oldPostOfComentarioListComentario.getComentarioList().remove(comentarioListComentario);
                    oldPostOfComentarioListComentario = em.merge(oldPostOfComentarioListComentario);
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findPost(post.getIdpost()) != null) {
                throw new PreexistingEntityException("Post " + post + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Post post) throws IllegalOrphanException, NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Post persistentPost = em.find(Post.class, post.getIdpost());
            Categoria categoriaOld = persistentPost.getCategoria();
            Categoria categoriaNew = post.getCategoria();
            Usuario prontuarioOld = persistentPost.getProntuario();
            Usuario prontuarioNew = post.getProntuario();
            List<Comentario> comentarioListOld = persistentPost.getComentarioList();
            List<Comentario> comentarioListNew = post.getComentarioList();
            List<String> illegalOrphanMessages = null;
            for (Comentario comentarioListOldComentario : comentarioListOld) {
                if (!comentarioListNew.contains(comentarioListOldComentario)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Comentario " + comentarioListOldComentario + " since its post field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            if (categoriaNew != null) {
                categoriaNew = em.getReference(categoriaNew.getClass(), categoriaNew.getIdcategoria());
                post.setCategoria(categoriaNew);
            }
            if (prontuarioNew != null) {
                prontuarioNew = em.getReference(prontuarioNew.getClass(), prontuarioNew.getProntuario());
                post.setProntuario(prontuarioNew);
            }
            List<Comentario> attachedComentarioListNew = new ArrayList<Comentario>();
            for (Comentario comentarioListNewComentarioToAttach : comentarioListNew) {
                comentarioListNewComentarioToAttach = em.getReference(comentarioListNewComentarioToAttach.getClass(), comentarioListNewComentarioToAttach.getIdcomentario());
                attachedComentarioListNew.add(comentarioListNewComentarioToAttach);
            }
            comentarioListNew = attachedComentarioListNew;
            post.setComentarioList(comentarioListNew);
            post = em.merge(post);
            if (categoriaOld != null && !categoriaOld.equals(categoriaNew)) {
                categoriaOld.getPostList().remove(post);
                categoriaOld = em.merge(categoriaOld);
            }
            if (categoriaNew != null && !categoriaNew.equals(categoriaOld)) {
                categoriaNew.getPostList().add(post);
                categoriaNew = em.merge(categoriaNew);
            }
            if (prontuarioOld != null && !prontuarioOld.equals(prontuarioNew)) {
                prontuarioOld.getPostList().remove(post);
                prontuarioOld = em.merge(prontuarioOld);
            }
            if (prontuarioNew != null && !prontuarioNew.equals(prontuarioOld)) {
                prontuarioNew.getPostList().add(post);
                prontuarioNew = em.merge(prontuarioNew);
            }
            for (Comentario comentarioListNewComentario : comentarioListNew) {
                if (!comentarioListOld.contains(comentarioListNewComentario)) {
                    Post oldPostOfComentarioListNewComentario = comentarioListNewComentario.getPost();
                    comentarioListNewComentario.setPost(post);
                    comentarioListNewComentario = em.merge(comentarioListNewComentario);
                    if (oldPostOfComentarioListNewComentario != null && !oldPostOfComentarioListNewComentario.equals(post)) {
                        oldPostOfComentarioListNewComentario.getComentarioList().remove(comentarioListNewComentario);
                        oldPostOfComentarioListNewComentario = em.merge(oldPostOfComentarioListNewComentario);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = post.getIdpost();
                if (findPost(id) == null) {
                    throw new NonexistentEntityException("The post with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Post post;
            try {
                post = em.getReference(Post.class, id);
                post.getIdpost();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The post with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<Comentario> comentarioListOrphanCheck = post.getComentarioList();
            for (Comentario comentarioListOrphanCheckComentario : comentarioListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Post (" + post + ") cannot be destroyed since the Comentario " + comentarioListOrphanCheckComentario + " in its comentarioList field has a non-nullable post field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Categoria categoria = post.getCategoria();
            if (categoria != null) {
                categoria.getPostList().remove(post);
                categoria = em.merge(categoria);
            }
            Usuario prontuario = post.getProntuario();
            if (prontuario != null) {
                prontuario.getPostList().remove(post);
                prontuario = em.merge(prontuario);
            }
            em.remove(post);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Post> findPostEntities() {
        return findPostEntities(true, -1, -1);
    }

    public List<Post> findPostEntities(int maxResults, int firstResult) {
        return findPostEntities(false, maxResults, firstResult);
    }

    private List<Post> findPostEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Post.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Post findPost(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Post.class, id);
        } finally {
            em.close();
        }
    }

    public int getPostCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Post> rt = cq.from(Post.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
    public String autoIncremento(){
        
        String sql = "SELECT CASE WHEN MAX(idpost) IS NULL THEN 1 ELSE MAX(idpost)+1 END AS IDNOVO FROM post;";
        
        try {
            String codigo;
            PreparedStatement stmte = this.con.prepareStatement(sql);
            ResultSet rs = stmte.executeQuery(sql);
            rs.first();
            codigo = (rs.getString("IDNOVO"));     
            
            return codigo;
        } catch (Exception e) {
            this.mens = "Erro: " + e.getMessage();
            return "ERRO";
        }
        
        
    }
    
}

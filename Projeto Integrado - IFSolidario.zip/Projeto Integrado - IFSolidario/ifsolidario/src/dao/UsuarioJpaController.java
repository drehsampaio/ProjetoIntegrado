/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import bean.Post;
import java.util.ArrayList;
import java.util.List;
import bean.Comentario;
import bean.Usuario;
import bean.Autenticacao;
import conexao.Conexao;
import dao.exceptions.IllegalOrphanException;
import dao.exceptions.NonexistentEntityException;
import dao.exceptions.PreexistingEntityException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author adria
 */
public class UsuarioJpaController implements Serializable {
    
    public UsuarioJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Usuario usuario) throws PreexistingEntityException, Exception {
        if (usuario.getPostList() == null) {
            usuario.setPostList(new ArrayList<Post>());
        }
        if (usuario.getComentarioList() == null) {
            usuario.setComentarioList(new ArrayList<Comentario>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            List<Post> attachedPostList = new ArrayList<Post>();
            for (Post postListPostToAttach : usuario.getPostList()) {
                postListPostToAttach = em.getReference(postListPostToAttach.getClass(), postListPostToAttach.getIdpost());
                attachedPostList.add(postListPostToAttach);
            }
            usuario.setPostList(attachedPostList);
            List<Comentario> attachedComentarioList = new ArrayList<Comentario>();
            for (Comentario comentarioListComentarioToAttach : usuario.getComentarioList()) {
                comentarioListComentarioToAttach = em.getReference(comentarioListComentarioToAttach.getClass(), comentarioListComentarioToAttach.getIdcomentario());
                attachedComentarioList.add(comentarioListComentarioToAttach);
            }
            usuario.setComentarioList(attachedComentarioList);
            em.persist(usuario);
            for (Post postListPost : usuario.getPostList()) {
                Usuario oldProntuarioOfPostListPost = postListPost.getProntuario();
                postListPost.setProntuario(usuario);
                postListPost = em.merge(postListPost);
                if (oldProntuarioOfPostListPost != null) {
                    oldProntuarioOfPostListPost.getPostList().remove(postListPost);
                    oldProntuarioOfPostListPost = em.merge(oldProntuarioOfPostListPost);
                }
            }
            for (Comentario comentarioListComentario : usuario.getComentarioList()) {
                Usuario oldProntuarioOfComentarioListComentario = comentarioListComentario.getProntuario();
                comentarioListComentario.setProntuario(usuario);
                comentarioListComentario = em.merge(comentarioListComentario);
                if (oldProntuarioOfComentarioListComentario != null) {
                    oldProntuarioOfComentarioListComentario.getComentarioList().remove(comentarioListComentario);
                    oldProntuarioOfComentarioListComentario = em.merge(oldProntuarioOfComentarioListComentario);
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findUsuario(usuario.getProntuario()) != null) {
                throw new PreexistingEntityException("Usuario " + usuario + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Usuario usuario) throws IllegalOrphanException, NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Usuario persistentUsuario = em.find(Usuario.class, usuario.getProntuario());
            List<Post> postListOld = persistentUsuario.getPostList();
            List<Post> postListNew = usuario.getPostList();
            List<Comentario> comentarioListOld = persistentUsuario.getComentarioList();
            List<Comentario> comentarioListNew = usuario.getComentarioList();
            List<String> illegalOrphanMessages = null;
            for (Post postListOldPost : postListOld) {
                if (!postListNew.contains(postListOldPost)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Post " + postListOldPost + " since its prontuario field is not nullable.");
                }
            }
            for (Comentario comentarioListOldComentario : comentarioListOld) {
                if (!comentarioListNew.contains(comentarioListOldComentario)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Comentario " + comentarioListOldComentario + " since its prontuario field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            List<Post> attachedPostListNew = new ArrayList<Post>();
            for (Post postListNewPostToAttach : postListNew) {
                postListNewPostToAttach = em.getReference(postListNewPostToAttach.getClass(), postListNewPostToAttach.getIdpost());
                attachedPostListNew.add(postListNewPostToAttach);
            }
            postListNew = attachedPostListNew;
            usuario.setPostList(postListNew);
            List<Comentario> attachedComentarioListNew = new ArrayList<Comentario>();
            for (Comentario comentarioListNewComentarioToAttach : comentarioListNew) {
                comentarioListNewComentarioToAttach = em.getReference(comentarioListNewComentarioToAttach.getClass(), comentarioListNewComentarioToAttach.getIdcomentario());
                attachedComentarioListNew.add(comentarioListNewComentarioToAttach);
            }
            comentarioListNew = attachedComentarioListNew;
            usuario.setComentarioList(comentarioListNew);
            usuario = em.merge(usuario);
            for (Post postListNewPost : postListNew) {
                if (!postListOld.contains(postListNewPost)) {
                    Usuario oldProntuarioOfPostListNewPost = postListNewPost.getProntuario();
                    postListNewPost.setProntuario(usuario);
                    postListNewPost = em.merge(postListNewPost);
                    if (oldProntuarioOfPostListNewPost != null && !oldProntuarioOfPostListNewPost.equals(usuario)) {
                        oldProntuarioOfPostListNewPost.getPostList().remove(postListNewPost);
                        oldProntuarioOfPostListNewPost = em.merge(oldProntuarioOfPostListNewPost);
                    }
                }
            }
            for (Comentario comentarioListNewComentario : comentarioListNew) {
                if (!comentarioListOld.contains(comentarioListNewComentario)) {
                    Usuario oldProntuarioOfComentarioListNewComentario = comentarioListNewComentario.getProntuario();
                    comentarioListNewComentario.setProntuario(usuario);
                    comentarioListNewComentario = em.merge(comentarioListNewComentario);
                    if (oldProntuarioOfComentarioListNewComentario != null && !oldProntuarioOfComentarioListNewComentario.equals(usuario)) {
                        oldProntuarioOfComentarioListNewComentario.getComentarioList().remove(comentarioListNewComentario);
                        oldProntuarioOfComentarioListNewComentario = em.merge(oldProntuarioOfComentarioListNewComentario);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                String id = usuario.getProntuario();
                if (findUsuario(id) == null) {
                    throw new NonexistentEntityException("The usuario with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(String id) throws IllegalOrphanException, NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Usuario usuario;
            try {
                usuario = em.getReference(Usuario.class, id);
                usuario.getProntuario();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The usuario with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            List<Post> postListOrphanCheck = usuario.getPostList();
            for (Post postListOrphanCheckPost : postListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Usuario (" + usuario + ") cannot be destroyed since the Post " + postListOrphanCheckPost + " in its postList field has a non-nullable prontuario field.");
            }
            List<Comentario> comentarioListOrphanCheck = usuario.getComentarioList();
            for (Comentario comentarioListOrphanCheckComentario : comentarioListOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Usuario (" + usuario + ") cannot be destroyed since the Comentario " + comentarioListOrphanCheckComentario + " in its comentarioList field has a non-nullable prontuario field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(usuario);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Usuario> findUsuarioEntities() {
        return findUsuarioEntities(true, -1, -1);
    }

    public List<Usuario> findUsuarioEntities(int maxResults, int firstResult) {
        return findUsuarioEntities(false, maxResults, firstResult);
    }

    private List<Usuario> findUsuarioEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Usuario.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Usuario findUsuario(String id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Usuario.class, id);
        } finally {
            em.close();
        }
    }

    public int getUsuarioCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Usuario> rt = cq.from(Usuario.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
    /*public Boolean logar(String prontuario, String senha){   
        EntityManager em = getEntityManager();
        UsuarioJpaController usuarioDAO = new UsuarioJpaController();
        
        String sql = "SELECT * FROM usuario WHERE prontuario=? AND Senha=?";
        
           try {
           PreparedStatement stmte = this.con.prepareStatement(sql);
           stmte.setString(1, prontuario);
           stmte.setString(2, senha);
           ResultSet rs = stmte.executeQuery();
           rs.first();                        
               Autenticacao.setProntuario(rs.getString("prontuario"));
               Autenticacao.setSenha(rs.getString("Senha"));
               Autenticacao.setEmail(rs.getString("email"));
               Autenticacao.setNome(rs.getString("nome"));
               Autenticacao.setTipo(rs.getString("tipo"));
               
               //this.mens = "Bem Vindo " + rs.getString("nome");   
               return true;
           
            

       } catch (Exception e) {
           this.mens = "Usuario não cadastrado " + e.getMessage();
           return false;
          
       }
           
    }*/
 
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import bean.Categoria;
import bean.Comentario;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import bean.Post;
import bean.Usuario;
import conexao.Conexao;
import dao.exceptions.NonexistentEntityException;
import dao.exceptions.PreexistingEntityException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author adria
 */
public class ComentarioJpaController implements Serializable {
    private String mens;
    private Connection con;
    
    public String getMens() {
        return mens;
        
    }

    public void setMens(String mens) {
        this.mens = mens;
    }
    public ComentarioJpaController(EntityManagerFactory emf) {
        this.emf = emf;
        this.con = Conexao.getConnection();
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Comentario comentario) throws PreexistingEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Post post = comentario.getPost();
            if (post != null) {
                post = em.getReference(post.getClass(), post.getIdpost());
                comentario.setPost(post);
            }
            Usuario prontuario = comentario.getProntuario();
            if (prontuario != null) {
                prontuario = em.getReference(prontuario.getClass(), prontuario.getProntuario());
                comentario.setProntuario(prontuario);
            }
            em.persist(comentario);
            if (post != null) {
                post.getComentarioList().add(comentario);
                post = em.merge(post);
            }
            if (prontuario != null) {
                prontuario.getComentarioList().add(comentario);
                prontuario = em.merge(prontuario);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findComentario(comentario.getIdcomentario()) != null) {
                throw new PreexistingEntityException("Comentario " + comentario + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Comentario comentario) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Comentario persistentComentario = em.find(Comentario.class, comentario.getIdcomentario());
            Post postOld = persistentComentario.getPost();
            Post postNew = comentario.getPost();
            Usuario prontuarioOld = persistentComentario.getProntuario();
            Usuario prontuarioNew = comentario.getProntuario();
            if (postNew != null) {
                postNew = em.getReference(postNew.getClass(), postNew.getIdpost());
                comentario.setPost(postNew);
            }
            if (prontuarioNew != null) {
                prontuarioNew = em.getReference(prontuarioNew.getClass(), prontuarioNew.getProntuario());
                comentario.setProntuario(prontuarioNew);
            }
            comentario = em.merge(comentario);
            if (postOld != null && !postOld.equals(postNew)) {
                postOld.getComentarioList().remove(comentario);
                postOld = em.merge(postOld);
            }
            if (postNew != null && !postNew.equals(postOld)) {
                postNew.getComentarioList().add(comentario);
                postNew = em.merge(postNew);
            }
            if (prontuarioOld != null && !prontuarioOld.equals(prontuarioNew)) {
                prontuarioOld.getComentarioList().remove(comentario);
                prontuarioOld = em.merge(prontuarioOld);
            }
            if (prontuarioNew != null && !prontuarioNew.equals(prontuarioOld)) {
                prontuarioNew.getComentarioList().add(comentario);
                prontuarioNew = em.merge(prontuarioNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = comentario.getIdcomentario();
                if (findComentario(id) == null) {
                    throw new NonexistentEntityException("The comentario with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Comentario comentario;
            try {
                comentario = em.getReference(Comentario.class, id);
                comentario.getIdcomentario();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The comentario with id " + id + " no longer exists.", enfe);
            }
            Post post = comentario.getPost();
            if (post != null) {
                post.getComentarioList().remove(comentario);
                post = em.merge(post);
            }
            Usuario prontuario = comentario.getProntuario();
            if (prontuario != null) {
                prontuario.getComentarioList().remove(comentario);
                prontuario = em.merge(prontuario);
            }
            em.remove(comentario);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Comentario> findComentarioEntities() {
        return findComentarioEntities(true, -1, -1);
    }

    public List<Comentario> findComentarioEntities(int maxResults, int firstResult) {
        return findComentarioEntities(false, maxResults, firstResult);
    }

    private List<Comentario> findComentarioEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Comentario.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Comentario findComentario(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Comentario.class, id);
        } finally {
            em.close();
        }
    }

    public int getComentarioCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Comentario> rt = cq.from(Comentario.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
        public List<Comentario> getComents(int idpost){
       String sql = "SELECT * from post p INNER JOIN comentario c ON p.idpost = c.post INNER JOIN usuario u ON u.prontuario = p.prontuario WHERE p.idpost = ?;";
       
       try {
            PreparedStatement stmte = this.con.prepareStatement(sql);
            stmte.setInt(1, idpost);
            ResultSet rs = stmte.executeQuery();
            List<Comentario> lista = new ArrayList();
            
            while(rs.next())
            {
                Comentario c = new Comentario();
                c.setIdcomentario(rs.getInt("idcomentario"));
                c.setComentario(rs.getString("comentario"));
                Post p = new Post();
                p.setIdpost(Integer.parseInt(rs.getString("post")));
                c.setPost(p);
                Usuario u = new Usuario();
                u.setProntuario(rs.getString("prontuario"));
                u.setNome(rs.getString("nome"));
                c.setProntuario(u);                                           
                
                lista.add(c);
            }
            return lista;
            
       } catch (Exception e) {
           this.mens = "Erro ao Listar Turmas: " + e.getMessage();
           return null;
       }
       
   }
    public String autoIncremento(){
        
        String sql = "SELECT CASE WHEN MAX(idcomentario) IS NULL THEN 1 ELSE MAX(idcomentario)+1 END AS IDNOVO FROM comentario;";
        
        try {
            String codigo;
            PreparedStatement stmte = this.con.prepareStatement(sql);
            ResultSet rs = stmte.executeQuery(sql);
            rs.first();
            codigo = (rs.getString("IDNOVO"));     
            
            return codigo;
        } catch (Exception e) {
            this.mens = "Erro: " + e.getMessage();
            return "ERRO";
        }
        
        
    }
    
}

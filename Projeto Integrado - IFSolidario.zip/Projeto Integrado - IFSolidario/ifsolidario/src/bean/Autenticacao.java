/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

/**
 *
 * @author adria
 */
public class Autenticacao {
    static String prontuario;
    static String senha; 
    static String email;
    static String Nome;
    static String tipo;

    public static String getProntuario() {
        return prontuario;
    }

    public static void setProntuario(String p) {
        prontuario = p;
    }

    public static String getSenha() {
        return senha;
    }

    public static void setSenha(String senha) {
        Autenticacao.senha = senha;
    }

    public static String getEmail() {
        return email;
    }

    public static void setEmail(String email) {
        Autenticacao.email = email;
    }

    public static String getNome() {
        return Nome;
    }

    public static void setNome(String Nome) {
        Autenticacao.Nome = Nome;
    }

    public static String getTipo() {
        return tipo;
    }

    public static void setTipo(String tipo) {
        Autenticacao.tipo = tipo;
    }

    
    
}
